#ifndef AP_AP_MAIN_H_
#define AP_AP_MAIN_H_
#include "LedBar.h"
#include "Button.h"
#include "FND_prof.h"
#include "stm32f4xx_hal.h"
#include "tim.h" //timer Handler
#include "stopWatch.h"
#include "timeWatch.h"

void ap_Init();
int ap_main();

#endif /* AP_AP_MAIN_H_ */
