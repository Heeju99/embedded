#ifndef AP_TIMEWATCH_H_
#define AP_TIMEWATCH_H_

#include "Button.h"
#include "FND_prof.h"
#include "stm32f4xx_hal.h"

void TimeWatch_IncTimeCallBack();
void TimeWatch_Excute();
void TimeWatch_Dot();

#endif /* AP_TIMEWATCH_H_ */
