#ifndef DRIVER_FND_PROF_FND_PROF_H_
#define DRIVER_FND_PROF_FND_PROF_H_

#include <stdint.h>
#include "stm32f4xx.h"
#include "stm32f4xx_hal.h"

void FND_WriteData(uint16_t data);
uint16_t FND_ReadData();
void FND_DisplayData();

#endif /* DRIVER_FND_PROF_FND_PROF_H_ */
