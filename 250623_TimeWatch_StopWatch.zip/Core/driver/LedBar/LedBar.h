#ifndef DRIVER_LEDBAR_LEDBAR_H_
#define DRIVER_LEDBAR_LEDBAR_H_
#include <stdint.h>
#include "stm32f4xx_hal.h"
#include "stm32f411xe.h"

void LEDBar_Write(uint8_t data);

#endif /* DRIVER_LEDBAR_LEDBAR_H_ */
