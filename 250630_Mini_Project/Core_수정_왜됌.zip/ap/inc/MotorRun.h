#ifndef AP_INC_MOTORRUN_H_
#define AP_INC_MOTORRUN_H_

#include "stm32f4xx_hal.h"
#include "Motor.h"
#include "tim.h"

void MotorRun_Init();
void MotorRUN_PowerOn();

#endif /* AP_INC_MOTORRUN_H_ */
