#include "Controller.h"

void Controller_Init()
{
	StopWatch_Init();
}


void Controller_Excute()
{
	StopWatch_Excute();
}

