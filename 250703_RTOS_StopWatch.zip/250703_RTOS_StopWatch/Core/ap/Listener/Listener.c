#include "Listener.h"

void Listener_Init()
{
	Listener_StopWatchInit();
}


void Listener_Excute()
{
	Listener_StopWatchExcute();
}
