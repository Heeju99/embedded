#ifndef AP_LISTENER_LISTENER_H_
#define AP_LISTENER_LISTENER_H_

#include "Listener_StopWatch.h"

void Listener_Init();
void Listener_Excute();

#endif /* AP_LISTENER_LISTENER_H_ */
