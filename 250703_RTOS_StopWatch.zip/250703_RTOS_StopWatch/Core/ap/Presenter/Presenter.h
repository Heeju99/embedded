#ifndef AP_PRESENTER_PRESENTER_H_
#define AP_PRESENTER_PRESENTER_H_

#include "Presenter_StopWatch.h"

void Presenter_Init();
void Presenter_Excute();

#endif /* AP_PRESENTER_PRESENTER_H_ */
