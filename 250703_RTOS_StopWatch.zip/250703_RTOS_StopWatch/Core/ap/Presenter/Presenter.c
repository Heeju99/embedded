#include "Presenter.h"

void Presenter_Init()
{
	//FND_INIT
	Presenter_StopWatch_Init();
}


void Presenter_Excute()
{
	//FND EXCUTE
	Presenter_StopWatch_Excute();
}
