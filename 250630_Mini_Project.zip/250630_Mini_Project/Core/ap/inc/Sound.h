
#ifndef AP_INC_SOUND_H_
#define AP_INC_SOUND_H_

#include "stm32f4xx_hal.h"
#include "Buzzer.h"
#include "tim.h"

void Sound_Init();
void Sound_Warning();

#endif /* AP_INC_SOUND_H_ */
